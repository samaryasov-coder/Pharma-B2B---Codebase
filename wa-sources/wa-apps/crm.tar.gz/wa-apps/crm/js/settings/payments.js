var CRMSettingsPayments = (function ($) {

    CRMSettingsPayments = function (options) {
        var that = this;

        // DOM
        that.$wrapper = options["$wrapper"];
        that.$dropdown = that.$wrapper.find(".dropdown");
        that.$pluginsDropdown = that.$wrapper.find(".js-plugins-dropdown");
        that.$table = that.$wrapper.find(".js-payments-table");

        // VARS
        that.company_id = options["company_id"];
        that.locales = options["locales"];

        // DYNAMIC VARS

        // INIT
        that.initClass();
    };

    CRMSettingsPayments.prototype.initClass = function () {
        var that = this;
        //
        that.initTabs();
        //
        that.initDelete();
        //
        that.initSortable();

        that.initDropDown();

        var $page_body = that.$wrapper.find(".c-payments-list");

        var observer = new MutationObserver(function (mutations) {
            $page_body.trigger("refresh");
        });

        observer.observe($page_body[0], {
            childList: true,
            attributes: true,
            subtree: true
        });
    };

    CRMSettingsPayments.prototype.initTabs = function () {
        var that = this,
            $section = that.$wrapper.find(".c-tabs-wrapper"),
            $companies = that.$wrapper.find(".c-companies-wrapper"),
            $list = $companies.find(".c-companies-list"),
            $activeTab = $list.find(".c-company.selected");

            initSetWidth();
            initSlider();
        //

        function initSetWidth() {
            var $window = $(window),
                other_w = $section.find(".c-add-wrapper").outerWidth();

            setWidth();

            $window.on("resize refresh", onResize);

            function onResize() {
                var is_exist = $.contains(document, $section[0]);
                if (is_exist) {
                    setWidth();
                } else {
                    $window.off("resize refresh", onResize);
                }
            }

            function setWidth() {
                var section_w = $section.outerWidth(true),
                    max_w = section_w - other_w - 38;
                $companies.css("max-width", max_w + "px");
            }
        }

        function initSlider() {
            $.crm.tabSlider({
                $wrapper: $companies,
                $slider: $list,
                $activeSlide: ($activeTab.length ? $activeTab : false)
            });
        }
    };

    CRMSettingsPayments.prototype.initDropDown = function () {
        var that = this;
        that.$dropdown.waDropdown();
    }

    CRMSettingsPayments.prototype.initDelete = function () {
        var that = this,
            is_locked = false;

        that.$wrapper.on("click", ".js-delete-payment", onDelete);

        function onDelete(event) {
            event.preventDefault();
            var $link = $(this),
                $tr = $link.closest("tr"),
                payment_id = $link.data("payment-id"),
                payment_plugin = $link.data("plugin");

            showConfirm();

            function showConfirm() {
                $.waDialog.confirm({
                    title: '<i class=\"fas fa-exclamation-triangle smaller state-error\"></i> ' + that.locales["confirm_delete_title"].replace("%payment", $tr.find(".js-name").text()),
                    text: that.locales["confirm_delete_text"],
                    success_button_title: that.locales["confirm_delete_button"],
                    success_button_class: 'danger',
                    cancel_button_title: that.locales["confirm_cancel_button"],
                    cancel_button_class: 'light-gray',
                    onSuccess: remove
                });

                function remove() {
                    if (!is_locked) {
                        is_locked = true;

                        var href = "?module=settings&action=paymentDelete",
                            data = {
                                id: payment_id,
                                company_id: that.company_id
                            };

                        $.post(href, data, function (response) {
                            if (response.status == "ok") {
                                $tr.remove();

                                var $plugin = that.$pluginsDropdown.find("li[data-plugin=\"" + payment_plugin + "\"]");
                                if ($plugin.length) {
                                    $plugin.show();
                                }
                            }
                        }).always(function () {
                            is_locked = false;
                        })
                    }
                }
            }
        }
    };

    CRMSettingsPayments.prototype.initSortable = function () {
        var that = this,
            xhr = false;

        var $t_body = that.$table.find('tbody');

        $t_body.sortable({
            distance: 10,
            handle: ".js-sort-toggle",
            helper: "clone",
            items: "> .payments-table-row",
            axis: "y",
            stop: save,
            onUpdate: save
        });

        function save() {
            var href = "?module=settings&action=paymentSort",
                ids = getIds(),
                data = {
                    ids: ids,
                    company_id: that.company_id
                };

            if (xhr) {
                xhr.abort();
            }

            xhr = $.post(href, data, function (response) {

            }).always(function () {
                xhr = false;
            });

            function getIds() {
                var result = [];

                that.$table.find("tr").each(function () {
                    result.push($(this).data("id"));
                });

                return result;
            }
        }
    };

    return CRMSettingsPayments;

})(jQuery);

var CRMPaymentEdit = (function ($) {

    CRMPaymentEdit = function (options) {
        var that = this;

        // DOM
        that.$wrapper = options["$wrapper"];
        that.$form = that.$wrapper.find("form");
        that.$footer = that.$wrapper.find(".js-footer");

        // VARS
        that.instance_id = options["instance_id"];
        that.company_id = options["company_id"];
        that.locales = options["locales"];

        // DYNAMIC VARS

        // INIT
        that.initClass();
    };

    CRMPaymentEdit.prototype.initClass = function () {
        var that = this;
        //
        that.initSubmit();
        //
        that.initDelete();
    };

    CRMPaymentEdit.prototype.initSubmit = function () {
        var that = this,
            is_locked = false,
            $form = that.$form;
        const $submit = $form.find('[type="submit"]');

        $form.on("submit", function (event) {
            event.preventDefault();
            var formData = getData();
            if (formData.errors.length) {
                showErrors(formData.errors);
            } else {
                submit(formData.data);
            }
        });

        function submit(data) {
            if (!is_locked) {
                is_locked = true;

                var saving = that.locales.saving,
                    $loading = $(saving);
                $submit.prepend($loading);
                $submit.prop('disabled', true);
                var href = "?module=settings&action=paymentSave";

                $.post(href, data, function (response) {
                    if (response.status == "ok") {
                        $loading.remove();
                        $submit.prop('disabled', false);
                        $submit.removeClass('yellow');

                        if (!that.instance_id) {
                            var content_uri = $.crm.app_url + "settings/payment/?company=" + that.company_id;
                            $.crm.content.load(content_uri);
                        } else {
                            var saved = that.locales.saved,
                                $saved = $(saved);
                            $submit.prepend($saved);
                            //
                            setTimeout(function () {
                                var is_exist = $.contains(document, $saved[0]);
                                if (is_exist) {
                                    $saved.remove();
                                }
                            }, 2000);
                        }
                    }
                }).always(function () {
                    is_locked = false;
                });
            }
        }

        function getData() {
            var result = {
                data: $form.serializeArray(),
                errors: []
            };

            return result;
        }

        function showErrors(errors, ajax_errors) {
            var error_class = "error";

            errors = (errors ? errors : []);

            if (ajax_errors) {
                var keys = Object.keys(ajax_errors);
                $.each(keys, function (index, name) {
                    errors.push({
                        name: name,
                        value: ajax_errors[name]
                    })
                });
            }

            $.each(errors, function (index, item) {
                var name = item.name,
                    text = item.value;

                var $field = that.$wrapper.find("[name=\"" + name + "\"]");

                if ($field.length && !$field.hasClass(error_class)) {

                    var $text = $("<span />").addClass("errormsg").text(text);
                    $text.insertAfter($field);

                    $field
                        .addClass(error_class)
                        .one("focus click", function () {
                            $field.removeClass(error_class);
                            $text.remove();
                        });
                }
            });
        }
    };

    CRMPaymentEdit.prototype.initDelete = function () {
        var that = this,
            is_locked = false;

        that.$wrapper.on("click", ".js-delete-payment", onDelete);

        function onDelete(event) {
            event.preventDefault();

            showConfirm();

            function showConfirm() {
                if (!is_locked) {
                    is_locked = true;

                    $.waDialog.confirm({
                        title: '<i class=\"fas fa-exclamation-triangle smaller state-error\"></i> ' + that.locales["confirm_delete_title"],
                        text: that.locales["confirm_delete_text"],
                        success_button_title: that.locales["confirm_delete_button"],
                        success_button_class: 'danger',
                        cancel_button_title: that.locales["confirm_cancel_button"],
                        cancel_button_class: 'light-gray',
                        onSuccess: remove
                    });
                }
                is_locked = false;
            }

            function remove() {
                if (!is_locked) {
                    is_locked = true;

                    var href = "?module=settings&action=paymentDelete",
                        data = {
                            id: that.instance_id,
                            company_id: that.company_id
                        };

                    $.post(href, data, function (response) {
                        if (response.status == "ok") {
                            var content_uri = $.crm.app_url + "settings/payment/?company=" + that.company_id;
                            $.crm.content.load(content_uri);
                        }
                    }).always(function () {
                        is_locked = false;
                    })
                }
            }
        }
    };

    return CRMPaymentEdit;

})(jQuery);
